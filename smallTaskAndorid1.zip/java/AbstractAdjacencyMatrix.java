import java.util.Arrays;
import java.util.Random;

/*
In general, an abstract class is a class that can declare and implement
common actions and data structures for extending concrete classes
enables avoiding duplicate code and encapsulation
On the other hand, it can declare abstract methods that must be implemented
in extending classes
 */
public abstract class AbstractAdjacencyMatrix implements BinaryMatrix {
    int[][] twoDimensionalArray;

    @Override
    public Integer getValue(Index index) {
        return twoDimensionalArray[index.getRow()][index.getColumn()];
    }

    @Override
    public void setValue(Index index, Integer value) {
        twoDimensionalArray[index.getRow()][index.getColumn()] = value;
        twoDimensionalArray[index.getColumn()][index.getRow()] = value;

    }


    public AbstractAdjacencyMatrix(int n) {
        twoDimensionalArray = new int[n][n];
        for (int row = 0; row < n; row++) {
            for (int column = 0; column <= row; column++) {
                twoDimensionalArray[row][column] = 0;
                twoDimensionalArray[column][row] = 0;
            }
        }
    }


    public AbstractAdjacencyMatrix(int[][] array) {
        this.twoDimensionalArray = new int[array.length][];
        for (int row = 0; row < array.length; row++) {
            this.twoDimensionalArray[row] = new int[array[row].length];
            System.arraycopy(array[row], 0, this.twoDimensionalArray[row], 0,
                    this.twoDimensionalArray[row].length);
        }
    }


    @Override
    public String toString() {
        StringBuilder matrixSb = new StringBuilder();
        for (int[] row : twoDimensionalArray) {
            matrixSb.append(Arrays.toString(row));
            matrixSb.append("\n");
        }
        return matrixSb.toString();
    }

}
