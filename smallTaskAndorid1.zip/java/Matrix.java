import java.util.Collection;

public interface Matrix<T> {
    T getValue(Index index);

    void setValue(Index index, T value);

    Collection<Integer> getNeighbors(Integer index);
}
