import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import java.util.stream.Collectors;

/*
1 0 0
1 1 1
0 1 1
 */

/**
 * This class uses the adapter pattern, also known as
 * wrapper/decorator/adapter.
 * It adapts a Matrix to the functionality of Graph Interface
 */
public class MatrixAdapter implements Traversable<Integer> {
    private AbstractAdjacencyMatrix innerMatrix;
    private Integer source;

    public MatrixAdapter(AbstractAdjacencyMatrix matrix) {
        this.innerMatrix = matrix;
    }

    public MatrixAdapter(int n) {
        this.innerMatrix = new StandardBinaryAdjacencyMatrix(n);
        source = 0;
    }

    public BinaryMatrix getInnerMatrix() {
        return innerMatrix;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(@NotNull Integer source) {
        this.source = source;
    }


    @Override
    public Node<Integer> getRoot() {
        return new Node<>(source);
    }

    /**
     * A reachable node is a node that wraps a neighboring index whose value is equal to 1
     *
     * @param aNode
     * @return
     */
    public Collection<Node<Integer>> getReachableNodes(Node<Integer> aNode) {
        return innerMatrix.getNeighbors(aNode.getData()).stream().map(x -> new Node<>(x, aNode)).collect(Collectors.toList());
    }
}
