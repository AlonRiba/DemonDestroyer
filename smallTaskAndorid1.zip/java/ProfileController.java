import java.util.*;
import java.util.stream.Collectors;

public class ProfileController {
    private final MatrixAdapter matrixAdapter;

    private final Map<Integer, Profile> nodes;

    public ProfileController(int numOfProfiles) {
        matrixAdapter = new MatrixAdapter(numOfProfiles);
        nodes = new HashMap<>();
        for (int i = 0; i < numOfProfiles; i++) {
            Profile profile = new Profile("itay", "bleic", 24.0);
            nodes.put(Math.toIntExact(profile.getId()), profile);
        }

    }

    public ProfileController(int[][] friends) {
        matrixAdapter = new MatrixAdapter(new StandardBinaryAdjacencyMatrix(friends));
        nodes = new HashMap<>();
        for (int i = 0; i < friends.length; i++) {
            Profile profile = new Profile("itay", "bleic", 24.0);
            nodes.put(Math.toIntExact(profile.getId()), profile);
        }

    }

    public void sendFriendRequest(Integer userRequesting, Integer userAccepting) {
        if (matrixAdapter.getInnerMatrix().getValue(new Index(userRequesting, userAccepting)).equals(1)) return;
        nodes.get(userAccepting).getToAcceptFriendsRequests().add(userRequesting);
    }

    public void acceptFriendRequest(Integer userRequesting, Integer userAccepting) {
        Set<Integer> friendsToAccept = nodes.get(userAccepting).getToAcceptFriendsRequests();
        if (!friendsToAccept.contains(userRequesting)) return;
        friendsToAccept.remove(userRequesting);
        matrixAdapter.getInnerMatrix().setValue(new Index(userRequesting, userAccepting), 1);
    }

    public void removeFriend(Integer userRequesting, Integer friendUser) {
        matrixAdapter.getInnerMatrix().setValue(new Index(userRequesting, friendUser), 0);
    }

    public List<Profile> getRelatedProfiles(Long from, Long to) {
        matrixAdapter.setSource(Math.toIntExact(from));
        DfsVisit<Integer> algorithm = new DfsVisit<>();
        Map<Integer, Integer> connectedComponent = algorithm.traverse(matrixAdapter).stream().collect(Collectors.toMap(Node::getData, integerNode -> Optional.ofNullable(integerNode.getParent()).map(Node::getData).orElse(-1)));
        if (!connectedComponent.containsKey(Math.toIntExact(to)))
            return null;
        return findPathByParent(from, to, connectedComponent).stream().map(nodes::get).collect(Collectors.toList());
    }

    public boolean isFriendsRelationExists(Long from, Long to) {
        return getRelatedProfiles(from, to) != null;
    }

    public Integer numberOfProfilesBetweenRelation(Long from, Long to) {
        return Optional.ofNullable(getRelatedProfiles(from, to)).map(List::size).orElse(null);
    }

    private List<Integer> findPathByParent(Long from, Long to, Map<Integer, Integer> connectedComponent) {
        List<Integer> path = new ArrayList<>();
        Integer currentNode = Math.toIntExact(to);
        Integer targetNode = Math.toIntExact(from);
        while (!currentNode.equals(targetNode) && !connectedComponent.get(currentNode).equals(targetNode)) {
            Integer parent = connectedComponent.get(currentNode);
            path.add(parent);
            currentNode = parent;
        }

        Collections.reverse(path);
        return path;
    }

}
