import java.util.Collection;

public interface BinaryMatrix extends Matrix<Integer> {
    Integer getValue(Index index);


    Collection<Integer> getNeighbors(Integer index);
}
