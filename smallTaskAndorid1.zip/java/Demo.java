import java.util.List;
import java.util.stream.Collectors;

public class Demo {
    public static void main(String[] args) {
        ProfileController profileController = new ProfileController(6);
        profileController.sendFriendRequest(0, 1);
        profileController.acceptFriendRequest(0, 1);

        profileController.sendFriendRequest(1, 2);
        profileController.acceptFriendRequest(1, 2);

        profileController.sendFriendRequest(1, 3);
        profileController.acceptFriendRequest(1, 3);


        profileController.sendFriendRequest(3, 4);
        profileController.acceptFriendRequest(3, 4);


        profileController.sendFriendRequest(4, 5);
        profileController.acceptFriendRequest(4, 5);


        Integer relatedProfiles = profileController.numberOfProfilesBetweenRelation(0L, 5L);

        System.out.println(relatedProfiles.equals(3));


        relatedProfiles = profileController.numberOfProfilesBetweenRelation(5L, 0L);

        System.out.println(relatedProfiles.equals(3));

        profileController.removeFriend(4, 5);

        relatedProfiles = profileController.numberOfProfilesBetweenRelation(0L, 5L);

        System.out.println(relatedProfiles == null);


        List<Profile> profileList = profileController.getRelatedProfiles(0L, 4L);
        System.out.println(profileList.get(0).getId().equals(1L));
        System.out.println(profileList.get(1).getId().equals(3L));


        System.out.println(profileController.isFriendsRelationExists(2L, 4L));

        //for this case its returning 1,3 (2,1,3,4) in case of using bfs it will return 1 (2,1,4) but this case is dfs
        System.out.println(profileController.getRelatedProfiles(2L, 4L).stream().map(Profile::getId).collect(Collectors.toList()));
    }
}
