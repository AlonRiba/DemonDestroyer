import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

public class StandardBinaryAdjacencyMatrix extends AbstractAdjacencyMatrix {
    public StandardBinaryAdjacencyMatrix(int n) {
        super(n);
    }

    public StandardBinaryAdjacencyMatrix(int[][] array) {
        super(array);
    }




    /*
                1 0 0
                1 1 0
                0 1 1
                 */
    @Override
    public Collection<Integer> getNeighbors(Integer index) {
        Set<Integer> neighbors = new LinkedHashSet<>();
        for (int i = 0; i < this.twoDimensionalArray[index].length; i++) {
            if (this.twoDimensionalArray[index][i] == 1)
                neighbors.add(i);
        }

        return neighbors;
    }

    @Override
    public String toString() {
        return super.toString() + "Standard";
    }

}
