import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class Profile {
    private final String firstName;
    private final String surName;
    private final UUID uuid;
    private final Long id;
    private final Double age;
    private static Long counter = 0L;

    private Set<Integer> friendRequests;


    public Profile(String firstName, String surName, Double age) {
        this.firstName = firstName;
        this.surName = surName;
        this.uuid = UUID.nameUUIDFromBytes((firstName + " " + surName).getBytes());
        this.id = counter;
        this.age = age;
        friendRequests = new HashSet<>();
        ++counter;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getSurName() {
        return surName;
    }

    public UUID getUuid() {
        return uuid;
    }

    public Long getId() {
        return id;
    }

    public Double getAge() {
        return age;
    }

    public static Long getCounter() {
        return counter;
    }

    public Set<Integer> getToAcceptFriendsRequests() {
        return friendRequests;
    }
}
